public class HelloWorld{
	
	public static void main(String []args){
	
	System.out.println("Amanda love food");
	System.out.println("Jonh loves Animal");
	//System.out.println();
	
	
	
	}

}

